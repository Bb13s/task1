import { getPublicNotes } from "@/lib/db";
import Link from "next/link";

export default function ExplorePage() {
  const notes = getPublicNotes();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">N</span>
            </div>
            <span className="font-bold text-xl text-gray-800">NoteHub</span>
          </div>
          <nav className="flex gap-4">
            <Link href="/" className="text-gray-600 hover:text-gray-900">首页</Link>
            <Link href="/explore" className="text-purple-600 font-medium">广场</Link>
            <Link href="/workspace" className="text-gray-600 hover:text-gray-900">工作区</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">笔记广场</h1>
          <p className="text-gray-600">发现社区中分享的公开笔记</p>
        </div>

        {notes.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl shadow-sm">
            <div className="text-6xl mb-4">📝</div>
            <h3 className="text-xl font-medium text-gray-700 mb-2">暂无公开笔记</h3>
            <p className="text-gray-500">成为第一个分享笔记的人吧！</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {notes.map((note) => (
              <Link
                key={note.id}
                href={`/notes/${note.id}`}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow block"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-semibold text-lg text-gray-800 line-clamp-2">
                    {note.title}
                  </h3>
                  {note.is_public === 1 && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                      公开
                    </span>
                  )}
                </div>

                <div className="space-y-2 text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">作者:</span>
                    <span className="font-medium text-gray-700">{note.author}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">路径:</span>
                    <span className="font-mono text-xs bg-gray-100 px-2 py-0.5 rounded">
                      {note.folder_path}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">创建:</span>
                    <span>{new Date(note.created_at).toLocaleDateString('zh-CN')}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-100">
                  <p className="text-sm text-gray-600 line-clamp-3">
                    {note.content || "暂无内容摘要"}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
