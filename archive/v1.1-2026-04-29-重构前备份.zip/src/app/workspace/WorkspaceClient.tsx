'use client';

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import Link from 'next/link';
import FolderTree from './FolderTree';
import MarkdownPreview from './MarkdownPreview';
import SimpleEditor from './SimpleEditor';
import FilePreview from './FilePreview';
import { Note, FileRecord } from '@/lib/db';
import JSZip from 'jszip';

interface Folder {
  id: number;
  name: string;
  parent_id: number | null;
  author: string;
  created_at: string;
}

interface WorkspaceClientProps {
  initialFolders: Folder[];
  initialNotes: Note[];
  initialFiles: FileRecord[];
  initialSelectedNote?: Note | null;
}

export default function WorkspaceClient({ initialFolders, initialNotes, initialFiles, initialSelectedNote }: WorkspaceClientProps) {
  const [folders, setFolders] = useState<Folder[]>(initialFolders);
  const [notes, setNotes] = useState<Note[]>(initialNotes);
  const [files, setFiles] = useState<FileRecord[]>(initialFiles);
  const [selectedFolder, setSelectedFolder] = useState(initialSelectedNote?.folder_path || '/');
  const [selectedNote, setSelectedNote] = useState<Note | null>(initialSelectedNote || null);
  const [selectedFile, setSelectedFile] = useState<FileRecord | null>(null);
  const [editorContent, setEditorContent] = useState(initialSelectedNote?.content || '');
  const [editorTitle, setEditorTitle] = useState(initialSelectedNote?.title || '');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [currentUser] = useState('demo');
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');

  // 获取所有笔记标题用于双链补全
  const noteTitles = useMemo(() => notes.map(n => n.title), [notes]);

  // 下载笔记为 Markdown 文件
  const handleDownloadNote = useCallback(() => {
    if (!selectedNote) return;

    const content = `# ${editorTitle}\n\n${editorContent}`;
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${editorTitle || 'untitled'}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [selectedNote, editorTitle, editorContent]);

  // 选中文件
  const handleSelectFile = useCallback((file: FileRecord) => {
    setSelectedFile(file);
    setSelectedNote(null); // 清除选中的笔记
  }, []);

  // 批量下载文件夹
  const handleDownloadFolder = useCallback(async (folderPath: string) => {
    const folderNotes = notes.filter(n => n.folder_path === folderPath);
    const folderFiles = files.filter(f => f.folder_path === folderPath);

    if (folderNotes.length === 0 && folderFiles.length === 0) {
      alert('该文件夹为空');
      return;
    }

    const zip = new JSZip();
    const folderName = folderPath === '/' ? 'root' : folderPath.split('/').pop() || 'folder';

    // 添加笔记到 zip
    folderNotes.forEach(note => {
      const content = `# ${note.title}\n\n${note.content || ''}`;
      zip.file(`${note.title}.md`, content);
    });

    // 添加文件到 zip
    for (const file of folderFiles) {
      try {
        const response = await fetch(file.path);
        const blob = await response.blob();
        zip.file(file.original_name, blob);
      } catch (error) {
        console.error(`Failed to download file ${file.original_name}:`, error);
      }
    }

    // 生成并下载 zip
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${folderName}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [notes, files]);

  // 刷新文件列表
  const refreshFiles = useCallback(async () => {
    try {
      const res = await fetch('/api/files');
      const data = await res.json();
      if (data.files) {
        setFiles(data.files);
      }
    } catch (error) {
      console.error('Failed to refresh files:', error);
    }
  }, []);

  const handleSelectNote = useCallback((note: Note) => {
    const latestNote = notes.find(n => n.id === note.id);
    const noteToUse = latestNote || note;
    setSelectedNote(noteToUse);
    setSelectedFile(null); // 清除选中的文件
    setEditorTitle(noteToUse.title);
    setEditorContent(noteToUse.content || '');
    setSaveStatus('saved');
  }, [notes]);

  const handleCreateNote = useCallback(async (folderPath: string) => {
    const res = await fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: '新笔记',
        content: '',
        folderPath,
        author: currentUser,
      }),
    });
    const data = await res.json();
    if (data.note) {
      setNotes(prev => [data.note, ...prev]);
      handleSelectNote(data.note);
    }
  }, [currentUser, handleSelectNote]);

  const handleCreateFolder = useCallback(async (name: string, parentId: number | null) => {
    const res = await fetch('/api/folders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, parentId, author: currentUser }),
    });
    const data = await res.json();
    if (data.folder) {
      setFolders(prev => [...prev, data.folder]);
    }
  }, [currentUser]);

  const handleDeleteFolder = useCallback(async (id: number) => {
    const res = await fetch(`/api/folders/${id}`, { method: 'DELETE' });
    if (res.ok) {
      setFolders(prev => prev.filter(f => f.id !== id));
      const notesRes = await fetch('/api/notes');
      const notesData = await notesRes.json();
      setNotes(notesData.notes || []);
    }
  }, []);

  const handleDeleteNote = useCallback(async (id: number) => {
    const res = await fetch(`/api/notes/${id}`, { method: 'DELETE' });
    if (res.ok) {
      setNotes(prev => prev.filter(n => n.id !== id));
      if (selectedNote?.id === id) {
        setSelectedNote(null);
        setEditorTitle('');
        setEditorContent('');
      }
    }
  }, [selectedNote]);

  const handleMoveNote = useCallback(async (noteId: number, folderPath: string) => {
    const res = await fetch(`/api/notes/${noteId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ folder_path: folderPath }),
    });
    if (res.ok) {
      setNotes(prev => prev.map(n => n.id === noteId ? { ...n, folder_path: folderPath } : n));
    }
  }, []);

  // 保存笔记
  const saveNote = useCallback(async (noteId: number, title: string, content: string) => {
    try {
      setSaveStatus('saving');
      const res = await fetch(`/api/notes/${noteId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content }),
      });

      if (res.ok) {
        setNotes(prev => prev.map(n =>
          n.id === noteId ? { ...n, title, content } : n
        ));
        setSaveStatus('saved');
        return true;
      }
      setSaveStatus('unsaved');
      return false;
    } catch (error) {
      console.error('Save error:', error);
      setSaveStatus('unsaved');
      return false;
    }
  }, []);

  // 处理编辑器内容变化
  const handleEditorChange = useCallback((newContent: string) => {
    console.log('Editor change received:', newContent.length, 'chars');
    setEditorContent(newContent);
    if (selectedNote) {
      setSaveStatus('unsaved');
    }
  }, [selectedNote]);

  // 自动保存（防抖）
  useEffect(() => {
    if (!selectedNote) return;

    // 如果内容没有变化，不需要保存
    if (editorTitle === selectedNote.title && editorContent === selectedNote.content) {
      setSaveStatus('saved');
      return;
    }

    const timeout = setTimeout(() => {
      saveNote(selectedNote.id, editorTitle, editorContent);
    }, 1500);

    return () => clearTimeout(timeout);
  }, [editorTitle, editorContent, selectedNote, saveNote]);

  // 上传文件
  const handleUploadFile = useCallback(async (folderPath: string, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('folderPath', folderPath);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (data.success) {
        await refreshFiles();
        alert(`文件 "${file.name}" 上传成功！`);
      } else {
        alert(`上传失败: ${data.error}`);
      }
    } catch (error) {
      alert('上传出错');
    }
  }, [refreshFiles]);

  // 删除文件
  const handleDeleteFile = useCallback(async (fileId: number) => {
    try {
      const res = await fetch(`/api/files?id=${fileId}`, { method: 'DELETE' });
      if (res.ok) {
        await refreshFiles();
      } else {
        alert('删除失败');
      }
    } catch (error) {
      alert('删除出错');
    }
  }, [refreshFiles]);

  return (
    <div className="h-screen flex flex-col bg-white">
      {/* Header */}
      <header className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="p-1.5 hover:bg-gray-100 rounded-md text-gray-600"
          >
            {isSidebarCollapsed ? '☰' : '←'}
          </button>
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">N</span>
            </div>
            <span className="font-bold text-lg text-gray-800">NoteHub</span>
          </Link>
        </div>
        <nav className="flex gap-4 text-sm">
          <Link href="/" className="text-gray-600 hover:text-gray-900">首页</Link>
          <Link href="/explore" className="text-gray-600 hover:text-gray-900">广场</Link>
          <Link href="/workspace" className="text-purple-600 font-medium">工作区</Link>
        </nav>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Folder Tree */}
        <div
          className={`border-r border-gray-200 bg-gray-50 transition-all duration-300 ${
            isSidebarCollapsed ? 'w-0 opacity-0 overflow-hidden' : 'w-72 opacity-100'
          }`}
        >
          <FolderTree
            folders={folders}
            notes={notes}
            files={files}
            selectedFolder={selectedFolder}
            selectedNoteId={selectedNote?.id || null}
            selectedFileId={selectedFile?.id || null}
            onSelectFolder={setSelectedFolder}
            onSelectNote={handleSelectNote}
            onSelectFile={handleSelectFile}
            onCreateFolder={handleCreateFolder}
            onCreateNote={handleCreateNote}
            onDeleteFolder={handleDeleteFolder}
            onDeleteNote={handleDeleteNote}
            onMoveNote={handleMoveNote}
            onUploadFile={handleUploadFile}
            onDeleteFile={handleDeleteFile}
            onRefreshFiles={refreshFiles}
            onDownloadFolder={handleDownloadFolder}
          />
        </div>

        {/* Middle Column - Editor */}
        <div className="flex-1 flex flex-col border-r border-gray-200 min-w-0">
          {selectedNote ? (
            <>
              <div className="px-4 py-3 border-b border-gray-200 bg-white">
                <div className="flex items-center justify-between">
                  <input
                    type="text"
                    value={editorTitle}
                    onChange={(e) => {
                      setEditorTitle(e.target.value);
                      setSaveStatus('unsaved');
                    }}
                    className="flex-1 text-xl font-semibold border-none focus:outline-none focus:ring-0 placeholder-gray-400"
                    placeholder="笔记标题"
                  />
                  <button
                    onClick={handleDownloadNote}
                    className="ml-2 px-3 py-1.5 text-sm bg-purple-100 text-purple-700 rounded hover:bg-purple-200 transition-colors"
                    title="下载为 Markdown 文件"
                  >
                    ⬇️ 下载
                  </button>
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                  <span>📁 {selectedNote.folder_path}</span>
                  <span>•</span>
                  <span className={`
                    ${saveStatus === 'saved' ? 'text-green-600' : ''}
                    ${saveStatus === 'saving' ? 'text-yellow-600' : ''}
                    ${saveStatus === 'unsaved' ? 'text-orange-500' : ''}
                  `}>
                    {saveStatus === 'saved' && '✓ 已保存'}
                    {saveStatus === 'saving' && '⏳ 保存中...'}
                    {saveStatus === 'unsaved' && '• 未保存'}
                  </span>
                </div>
              </div>
              <div className="flex-1 overflow-hidden">
                <SimpleEditor
                  value={editorContent}
                  onChange={handleEditorChange}
                  placeholder="# 开始编写 Markdown..."
                />
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
              <div className="text-6xl mb-4">📝</div>
              <p className="text-lg mb-2">选择一个笔记开始编辑</p>
              <p className="text-sm">或右键点击文件夹创建新笔记</p>
            </div>
          )}
        </div>

        {/* Right Column - Preview */}
        <div className="flex-1 bg-white overflow-hidden min-w-0">
          {selectedNote ? (
            <div className="h-full overflow-auto">
              <MarkdownPreview content={editorContent} />
            </div>
          ) : selectedFile ? (
            <FilePreview file={selectedFile} />
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-gray-400">
              <div className="text-6xl mb-4">👁️</div>
              <p className="text-lg">实时预览</p>
              <p className="text-sm mt-2">选择笔记或文件查看预览</p>
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="h-7 bg-gray-100 border-t border-gray-200 flex items-center justify-between px-3 text-xs text-gray-500 shrink-0">
        <div className="flex items-center gap-4">
          <span>{selectedNote ? `字数: ${editorContent.length}` : '就绪'}</span>
          {selectedNote && (
            <span className={`
              ${saveStatus === 'saved' ? 'text-green-600' : ''}
              ${saveStatus === 'saving' ? 'text-yellow-600' : ''}
              ${saveStatus === 'unsaved' ? 'text-orange-500' : ''}
            `}>
              {saveStatus === 'saved' && '✓ 已保存'}
              {saveStatus === 'saving' && '⏳ 保存中...'}
              {saveStatus === 'unsaved' && '• 未保存'}
            </span>
          )}
        </div>
        <div className="flex items-center gap-4">
          <span>当前文件夹: {selectedFolder}</span>
          <span>用户: {currentUser}</span>
        </div>
      </div>
    </div>
  );
}
