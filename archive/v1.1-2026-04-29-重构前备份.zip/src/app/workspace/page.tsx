import { getAllFolders, getAllNotes, seedData, getNoteById, getFilesByUploader } from '@/lib/db';
import WorkspaceClient from './WorkspaceClient';

interface WorkspacePageProps {
  searchParams: { note?: string };
}

export default function WorkspacePage({ searchParams }: WorkspacePageProps) {
  // 确保种子数据已插入
  seedData();

  const folders = getAllFolders('demo');
  const notes = getAllNotes('demo');
  const files = getFilesByUploader('demo');

  // 如果有 note 参数，获取对应笔记
  const initialNoteId = searchParams.note ? parseInt(searchParams.note) : null;
  const initialNote = initialNoteId ? getNoteById(initialNoteId, 'demo') : null;

  return (
    <WorkspaceClient
      initialFolders={folders}
      initialNotes={notes}
      initialFiles={files}
      initialSelectedNote={initialNote}
    />
  );
}
