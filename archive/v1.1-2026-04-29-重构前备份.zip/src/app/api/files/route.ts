import { NextRequest, NextResponse } from 'next/server';
import { unlink } from 'fs/promises';
import path from 'path';
import { getFilesByUploader, deleteFileRecord, getFileById, migrateFilesTable } from '@/lib/db';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');

// 获取文件列表
export async function GET(request: NextRequest) {
  try {
    // 确保表存在
    migrateFilesTable();

    const { searchParams } = new URL(request.url);
    const author = searchParams.get('author') || 'demo';

    const files = getFilesByUploader(author);

    return NextResponse.json({ files });
  } catch (error) {
    console.error('Get files error:', error);
    return NextResponse.json(
      { error: '获取文件列表失败' },
      { status: 500 }
    );
  }
}

// 删除文件
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const fileId = searchParams.get('id');

    if (!fileId) {
      return NextResponse.json(
        { error: '缺少文件ID' },
        { status: 400 }
      );
    }

    const fileRecord = getFileById(parseInt(fileId));
    if (!fileRecord) {
      return NextResponse.json(
        { error: '文件不存在' },
        { status: 404 }
      );
    }

    // 删除物理文件
    const filePath = path.join(UPLOAD_DIR, fileRecord.filename);
    try {
      await unlink(filePath);
    } catch (err) {
      console.error('Delete physical file error:', err);
      // 即使文件不存在也继续删除数据库记录
    }

    // 删除数据库记录
    const success = deleteFileRecord(parseInt(fileId), 'demo');

    if (success) {
      return NextResponse.json({ success: true });
    } else {
      return NextResponse.json(
        { error: '删除失败' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Delete file error:', error);
    return NextResponse.json(
      { error: '删除文件失败' },
      { status: 500 }
    );
  }
}
